def hello():
    return "Hello, Poetry!"